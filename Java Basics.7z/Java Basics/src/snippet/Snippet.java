package snippet;

public class Snippet {
	Write a Java program to print the area and perimeter of a circle.
}

