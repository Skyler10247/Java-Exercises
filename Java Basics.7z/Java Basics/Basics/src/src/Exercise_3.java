//Basics - Exercise 3: Write a Java program to divide two numbers and print on the screen.

package src;

public class Exercise_3 {

	public static void main(String[] args) {
		
		//Print '12 / 3' and the answer.
		System.out.print("12 / 3 = " + (12 / 3));

	}

}
