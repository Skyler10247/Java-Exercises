//Basics - Exercise 8: Write a Java program to display the following pattern.
//   J    a   v     v  a                                                  
//   J   a a   v   v  a a                                                 
//J  J  aaaaa   V V  aaaaa                                                
// JJ  a     a   V  a     a

package src;

public class Exercise_8 {

	public static void main(String[] args) {
		
		System.out.println("   J    a   v     v  a\n   J   a a   v   v  a a\nJ  J  aaaaa   V V  aaaaa\n JJ  a     a   V  a     a");

	}

}
