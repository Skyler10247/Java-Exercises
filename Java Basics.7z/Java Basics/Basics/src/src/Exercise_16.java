//Basics - Exercise 16: Write a Java program to print a face.

package src;

public class Exercise_16 {

	public static void main(String[] args) {
		
		System.out.println(" +\"\"\"\"\"+\r\n"
				+ "[| o o |]\r\n"
				+ " |  ^  |\r\n"
				+ " | '-' |\r\n"
				+ " +-----+");
	}

}
