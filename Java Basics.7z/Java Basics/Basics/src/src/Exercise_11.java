//Basics - Exercise 11: Write a Java program to print the area and perimeter of a circle.

package src;

public class Exercise_11 {

	public static void main(String[] args) {
		
		double perimeter = 7.5 * Math.PI * 2;
		double area = 7.5 * 7.5 * Math.PI;
		System.out.println("Radius: 7.5\nPerimeter: " + perimeter + "\nArea: " + area);
		
	}

}
