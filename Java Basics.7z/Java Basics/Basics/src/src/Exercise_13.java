//Basics - Exercise 13: Write a Java program to print the area and perimeter of a rectangle.

package src;

public class Exercise_13 {

	public static void main(String[] args) {
		
		System.out.println("Width = 5.5\nHeight = 8.5\n");
		double area = 5.5 * 8.5;
		double perimeter = 2 * (5.5 + 8.5);
		System.out.println("Area = " + area + "\nPerimeter: " + perimeter);

	}

}
