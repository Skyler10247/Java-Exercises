//Basics - Exercise 1: Write a Java program to print 'Hello' on screen and then print your name on a separate line.

package src;

public class Exercise_1 {

	public static void main(String[] args) {
		
		//Print 'Hello' and name.
		System.out.println("Hello,\nSkyler");
		
	}

}
