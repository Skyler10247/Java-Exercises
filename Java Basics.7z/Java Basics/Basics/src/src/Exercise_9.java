// Basics - Exercise 9: Write a Java program to compute the specified expressions and print the output.
//((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5))

package src;

public class Exercise_9 {

	public static void main(String[] args) {
		
		System.out.println(((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5)));

	}

}
