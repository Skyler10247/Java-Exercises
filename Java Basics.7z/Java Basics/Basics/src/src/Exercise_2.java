//Basics - Exercise 2: Write a Java program to print the sum of two numbers.

package src;

public class Exercise_2 {

	public static void main(String[] args) {
		
		//Print '12 + 7' and the answer.
		System.out.println("12 + 7 = " + (12 + 7));
		
	}
	
}
